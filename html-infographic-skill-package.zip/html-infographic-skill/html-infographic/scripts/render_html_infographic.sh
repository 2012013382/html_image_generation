#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 INPUT_HTML OUTPUT_PNG [WIDTH] [HEIGHT]" >&2
  exit 1
fi

INPUT_HTML="$1"
OUTPUT_PNG="$2"
WIDTH="${3:-1800}"
HEIGHT="${4:-1080}"

if [[ ! -f "$INPUT_HTML" ]]; then
  echo "Input HTML not found: $INPUT_HTML" >&2
  exit 1
fi

CHROME_BIN=""
for candidate in \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Chromium.app/Contents/MacOS/Chromium" \
  "$(command -v google-chrome 2>/dev/null || true)" \
  "$(command -v chromium 2>/dev/null || true)" \
  "$(command -v chromium-browser 2>/dev/null || true)"; do
  if [[ -n "$candidate" && -x "$candidate" ]]; then
    CHROME_BIN="$candidate"
    break
  fi
done

if [[ -z "$CHROME_BIN" ]]; then
  echo "No Chrome/Chromium executable found for headless rendering." >&2
  exit 1
fi

mkdir -p "$(dirname "$OUTPUT_PNG")"

"$CHROME_BIN" \
  --headless \
  --disable-gpu \
  --hide-scrollbars \
  --window-size="${WIDTH},${HEIGHT}" \
  --screenshot="$OUTPUT_PNG" \
  "file://$INPUT_HTML"

echo "$OUTPUT_PNG"
