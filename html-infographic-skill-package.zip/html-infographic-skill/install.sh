#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/html-infographic"
DEST_ROOT="${1:-}"

if [[ -z "$DEST_ROOT" ]]; then
  echo "Usage: bash install.sh /path/to/skills-root" >&2
  exit 1
fi

if [[ ! -d "$SOURCE_DIR" ]]; then
  echo "Skill directory not found: $SOURCE_DIR" >&2
  exit 1
fi

mkdir -p "$DEST_ROOT"
DEST_DIR="$DEST_ROOT/html-infographic"

if [[ -e "$DEST_DIR" ]]; then
  echo "Destination already exists: $DEST_DIR" >&2
  echo "Remove the existing folder or choose a different skills root." >&2
  exit 1
fi

cp -R "$SOURCE_DIR" "$DEST_DIR"

echo "Installed skill to: $DEST_DIR"
echo "Restart your client/app to pick up the new skill."
