---
name: html-infographic
description: Use when the task is to create or revise a one-page infographic, 信息图, 老板汇报图, 一页图, or executive visual summary and text layout reliability matters. This skill uses HTML/CSS for layout, renders with a real browser, and visually verifies that no text overflows or collides before delivery.
---

# HTML Infographic

Use this skill for single-image infographic deliverables where typography, Chinese text wrapping, and box layout must survive review. This is the default path for executive summary posters, boss-report visuals, one-page strategy graphics, and other dense information layouts.

Do not default to hand-positioned SVG text for these tasks. Use browser layout first.

## When To Use

Trigger this skill when the user asks for any of the following:

- 信息图 / infographic
- 老板汇报图 / 一页图 / 战略页
- one-page visual summary
- executive poster or report graphic
- revise an existing infographic that currently has text overflow, clipping, or collision

## Workflow

### 1. Structure the content first

Before building, reduce the content into 3-5 blocks with a clear hierarchy:

- problem
- solution
- flow
- value
- next steps

Cut explanatory copy until each block can be scanned quickly.

### 2. Build in HTML/CSS, not SVG

Create an HTML file sized for the intended export, usually `1800x1080`.

Use:

- CSS Grid and Flexbox for structure
- normal text flow for all body copy
- only minimal absolute positioning for decorative accents
- real spacing, padding, and max widths instead of manual x/y text placement

Prefer a restrained layout with a small number of panels and strong section headers.

## 3. Render with a real browser

Use `scripts/render_html_infographic.sh` to generate the PNG from the HTML.

Example:

```bash
bash /path/to/html-infographic/scripts/render_html_infographic.sh \
  /absolute/path/to/infographic.html \
  /absolute/path/to/infographic.png
```

Default output size is `1800x1080`. Pass width and height only if the brief needs a different canvas.
The key requirement is to use the bundled `scripts/render_html_infographic.sh` from the installed skill folder, whatever product-specific skill root that folder lives under.

### 4. Visually verify the render

Always inspect the rendered PNG with an image viewer tool before delivering.

Reject the output if any of these are present:

- text crosses card boundaries
- two blocks visually collide
- bottom content is clipped
- headline or subtitle is too wide for the canvas
- note boxes cover main copy
- the first glance does not make the hierarchy obvious

If any of those happen, fix the HTML/CSS and re-render. Do not ship "close enough."

### 5. Deliver the right artifacts

Default deliverables:

- final PNG for viewing
- source HTML for future edits

Keep the HTML as the editable source of truth. Only use SVG as an export format when the content is already stable and the browser render has been validated.

## Guardrails

- Use browser layout as the typography engine.
- Keep copy short enough for a leader to scan in 20-30 seconds.
- Prefer fewer sections with stronger hierarchy over many tiny cards.
- Do not cram product-level interaction details into the boss version.
- When revising a broken infographic, rebuild the layout in HTML/CSS instead of nudging overflowing text in SVG.

## Fast Checklist

Before delivery, confirm all of the following:

- HTML source exists
- PNG was rendered from the HTML
- image was visually reviewed
- no overflow or clipping remains
- hierarchy is readable from top to bottom
- file paths returned to the user point to the final PNG and HTML

## Resources

### `scripts/render_html_infographic.sh`

Deterministic renderer for turning a local HTML infographic into a PNG using headless Chrome.

### `assets/base-infographic.html`

Starter scaffold for a clean infographic poster with a gradient backdrop, top summary board, bottom flow board, and footer summary.
