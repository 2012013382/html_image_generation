# html-infographic Skill Package

Portable package for installing the `html-infographic` skill into Codex-like clients, Qoder-like products, or any tool that loads custom skills from a folder.

## Included

- `html-infographic/SKILL.md`
- `html-infographic/agents/openai.yaml`
- `html-infographic/assets/base-infographic.html`
- `html-infographic/scripts/render_html_infographic.sh`
- `install.sh`

## Install

### Option 1: Copy the folder manually

1. Unzip this package.
2. Copy the `html-infographic` folder into your product's custom skills directory.
3. Restart the client so it reloads skills.

Typical examples:

- Codex-style clients: `~/.codex/skills/`
- Other products: their configured `skills/` or `custom-skills/` directory

### Option 2: Use the installer script

```bash
bash install.sh /path/to/skills-root
```

Example:

```bash
bash install.sh ~/.codex/skills
```

## What the skill does

This skill is meant for one-page infographics, executive summary posters, and dense visual summaries where text layout reliability matters. It uses HTML/CSS for layout, renders through a real browser, and validates that text does not overflow or collide before delivery.

## Runtime Requirement

The bundled render script expects one of these browsers to be available:

- Google Chrome
- Chromium
- chromium-browser

## Notes

- The editable source of truth is HTML, not SVG.
- The render helper lives at `html-infographic/scripts/render_html_infographic.sh`.
- The starter template lives at `html-infographic/assets/base-infographic.html`.
